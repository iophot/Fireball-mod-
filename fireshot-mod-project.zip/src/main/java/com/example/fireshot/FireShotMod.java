package com.example.fireshot;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

// Мод: ПКМ огненным шаром (Fire Charge) = выстрел как у гаста.
// Обычный шар в Майне просто поджигает блок. Мы вклиниваемся в момент клика
// и вместо поджога запускаем настоящий огненный снаряд.
public class FireShotMod implements ModInitializer {

    // Сила взрыва. 1 = как у гаста. 2-3 = мощнее (и сильнее отбрасывает, как в Бедварсе)
    public static final int EXPLOSION_POWER = 1;

    // Пауза между выстрелами в тиках (20 тиков = 1 секунда)
    public static final int COOLDOWN_TICKS = 20;

    @Override
    public void onInitialize() {
        // Клик по ВОЗДУХУ предметом
        UseItemCallback.EVENT.register((player, world, hand) -> shoot(player, world, hand));

        // Клик по БЛОКУ предметом. Нужен отдельно, иначе игра сначала успеет поджечь блок.
        // Если вернуть SUCCESS, ванильный поджог отменяется.
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> shoot(player, world, hand));
    }

    private static ActionResult shoot(PlayerEntity player, World world, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        // Не огненный шар в руке? Не вмешиваемся, пусть игра делает своё
        if (!stack.isOf(Items.FIRE_CHARGE) || player.isSpectator()) {
            return ActionResult.PASS;
        }

        // Ещё перезаряжается? Ничего не делаем
        if (player.getItemCooldownManager().isCoolingDown(stack)) {
            return ActionResult.FAIL;
        }

        // Выстрел спавнится только на сервере. На клиенте просто машем рукой.
        if (!(world instanceof ServerWorld serverWorld)) {
            return ActionResult.SUCCESS;
        }

        // Куда смотрит игрок (длина 1)
        Vec3d look = player.getRotationVector();

        // Сам снаряд. Параметры: мир, кто стреляет, направление, сила взрыва
        FireballEntity fireball = new FireballEntity(serverWorld, player, look, EXPLOSION_POWER);

        // Ставим чуть впереди глаз, чтобы шар не взорвался в лице
        fireball.setPosition(player.getEyePos().add(look.multiply(1.5)));

        serverWorld.spawnEntity(fireball);

        // Звук выстрела как у гаста
        world.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.ENTITY_GHAST_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.0f);

        // Пауза ставится ДО того, как шар пропадёт из стопки
        player.getItemCooldownManager().set(stack, COOLDOWN_TICKS);

        // В выживании тратим 1 шар, в креативе бесплатно
        if (!player.isCreative()) {
            stack.decrement(1);
        }

        return ActionResult.SUCCESS;
    }
}
